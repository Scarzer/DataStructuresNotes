Project was written and completed in collaboration of Irving Derin and Asad Kamal

Included in the tar is this file. The stats.h file which was provided to us by the assignment, and stats.cpp.

stats.h 
------------
Header file that includes the class declerations for the statistician class. It was modified slightly to include Irving's and Ashar's names


stats.cpp
-------------
Class implementation file for the Statistician Class. It was written from the bottom up. It recieved a 90/90 score by the included exam program. 
